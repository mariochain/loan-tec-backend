export class LoginDto {
  controlNumber: string;
  password: string;
}
