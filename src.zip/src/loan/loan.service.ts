import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Loan } from './loan.entity';
import { User } from '../user/user.entity';
import { Material } from '../material/material.entity';
import { UpdateLoanDto } from './dto/update-loan.dto';

@Injectable()
export class LoanService {
  constructor(
    @InjectRepository(Loan)
    private loanRepository: Repository<Loan>,
    @InjectRepository(User)
    private userRepository: Repository<User>,
    @InjectRepository(Material)
    private materialRepository: Repository<Material>,
  ) {}

  // Solicitar un préstamo
  async requestLoan(
    userId: string,
    materials: { materialId: string; quantity: number }[],
  ): Promise<any> {
    const user = await this.userRepository.findOneBy({ idUser: userId }); // Cambiado a findOneBy para buscar por id
    if (!user) {
      throw new NotFoundException('Usuario no encontrado');
    }

    const loan = new Loan();
    loan.user = user;
    loan.status = 'pendiente';

    const loanMaterials = [];

    for (const item of materials) {
      const material = await this.materialRepository.findOneBy({
        idMaterial: item.materialId,
      }); // Cambiado a findOneBy
      if (!material) {
        throw new NotFoundException(
          `Material con ID ${item.materialId} no encontrado`,
        );
      }

      if (material.stock < item.quantity) {
        throw new Error(
          `Stock insuficiente para el material: ${material.name}`,
        );
      }

      material.stock -= item.quantity;
      await this.materialRepository.save(material);

      loanMaterials.push({
        material,
        quantityLoaned: item.quantity,
        quantityReturned: 0,
      });
    }

    loan.materials = loanMaterials;
    await this.loanRepository.save(loan);

    return {
      status: 'success',
      message: 'Préstamo solicitado correctamente',
      loanId: loan.id,
    };
  }

  // Actualizar un préstamo
  async updateLoan(id: number, updateLoanDto: UpdateLoanDto): Promise<Loan> {
    const loan = await this.loanRepository.findOne({
      where: { id },
      relations: ['materials', 'user'],
    }); // Cambiado para evitar el segundo parámetro en findOne
    if (!loan) {
      throw new NotFoundException('Préstamo no encontrado');
    }

    if (updateLoanDto.status) loan.status = updateLoanDto.status;
    await this.loanRepository.save(loan);
    return loan;
  }

  // Obtener el historial de préstamos por usuario
  async getLoanHistory(userId: string): Promise<Loan[]> {
    return this.loanRepository.find({
      where: { user: { idUser: userId } },
      relations: ['materials', 'user'],
    });
  }

  // Obtener los detalles de un préstamo
  async getLoanDetails(id: number): Promise<Loan> {
    const loan = await this.loanRepository.findOne({
      where: { id },
      relations: ['materials', 'user'],
    }); // Cambiado a findOne con opciones correctas
    if (!loan) {
      throw new NotFoundException('Préstamo no encontrado');
    }
    return loan;
  }
}
