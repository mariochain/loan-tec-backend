import {
  Controller,
  Post,
  Patch,
  Get,
  Param,
  Body,
  UseGuards,
  Request,
} from '@nestjs/common';
import { LoanService } from './loan.service';
import { CreateLoanDto } from './dto/create-loan.dto';
import { UpdateLoanDto } from './dto/update-loan.dto';
import { Roles } from 'src/auth/roles.decorator';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { RolesGuard } from 'src/auth/roles.guard';

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('loans')
export class LoanController {
  constructor(private readonly loanService: LoanService) {}

  @Post('request')
  async requestLoan(@Body() createLoanDto: CreateLoanDto, @Request() req) {
    return this.loanService.requestLoan(
      req.user.userId,
      createLoanDto.materials,
    );
  }

  @Roles('Administrador')
  @Patch('update/:id')
  async updateLoan(
    @Param('id') id: number,
    @Body() updateLoanDto: UpdateLoanDto,
  ) {
    return this.loanService.updateLoan(id, updateLoanDto);
  }

  @Get('history/:userId')
  async getLoanHistory(@Param('userId') userId: string) {
    return this.loanService.getLoanHistory(userId);
  }

  @Get('details/:id')
  async getLoanDetails(@Param('id') loanId: number) {
    return this.loanService.getLoanDetails(loanId);
  }
}
