import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  ManyToMany,
  JoinTable,
} from 'typeorm';
import { User } from '../user/user.entity';
import { Material } from '../material/material.entity';

@Entity()
export class Loan {
  @PrimaryGeneratedColumn()
  id: number;

  // eslint-disable-next-line prettier/prettier
  @ManyToOne(() => User, user => user.loans)
  user: User;

  @ManyToMany(() => Material)
  @JoinTable()
  materials: Material[];

  @Column()
  status: string;

  @Column({ default: 0 })
  quantityLoaned: number;

  @Column({ default: 0 })
  quantityReturned: number;

  @Column()
  comments: string;
}
