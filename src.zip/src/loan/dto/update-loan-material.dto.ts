import { IsInt } from 'class-validator';

export class UpdateLoanMaterialDto {
  @IsInt()
  materialId: number;

  @IsInt()
  quantityReturned: number;
}
