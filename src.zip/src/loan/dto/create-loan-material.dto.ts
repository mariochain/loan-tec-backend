import { IsInt } from 'class-validator';

export class CreateLoanMaterialDto {
  @IsInt()
  materialId: string;

  @IsInt()
  quantity: number;
}
