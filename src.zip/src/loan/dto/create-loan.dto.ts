import { IsInt, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { CreateLoanMaterialDto } from './create-loan-material.dto';

export class CreateLoanDto {
  @IsInt()
  userId: number;

  @ValidateNested({ each: true })
  @Type(() => CreateLoanMaterialDto)
  materials: CreateLoanMaterialDto[];
}
