import { IsString, IsOptional, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { UpdateLoanMaterialDto } from './update-loan-material.dto';

export class UpdateLoanDto {
  @IsString()
  @IsOptional()
  status?: string; // 'aprobado', 'pendiente', 'entregado'

  @ValidateNested({ each: true })
  @Type(() => UpdateLoanMaterialDto)
  @IsOptional()
  materials?: UpdateLoanMaterialDto[];
}
