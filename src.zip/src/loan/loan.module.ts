import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LoanService } from './loan.service';
import { Loan } from './loan.entity';
import { Material } from '../material/material.entity'; // Importamos la entidad Material
import { User } from '../user/user.entity'; // Importamos la entidad User
import { LoanController } from './loan.controller';

@Module({
  imports: [TypeOrmModule.forFeature([Loan, Material, User])], // Importamos las entidades Loan, Material y User
  providers: [LoanService], // Registramos el servicio de Loan
  controllers: [LoanController],
  exports: [LoanService], // Exportamos el servicio de Loan para su uso en otros módulos
})
export class LoanModule {}
