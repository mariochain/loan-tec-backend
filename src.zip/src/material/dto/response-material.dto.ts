export class MaterialResponseDto {
  idMaterial: string;
  name: string;
  description: string;
  stock: number;
  urlImage: string;
  categoryName: string;
}
